var canvas;
var ctx;
var XPOS = myCanvas.width / 2;
var YPOS = myCanvas.height / 2;
//------------------
var newName;
var add;
var deleted;
var option;
var lista_out;
//------------------


function initFunctions() {
    //-------------------------------------------------------
    canvas = document.getElementById('myCanvas');
    ctx = canvas.getContext('2d');
    drawCircle();
    window.addEventListener("keydown", movement, false);
    //-------------------------------------------------------
    name = document.getElementById("NewName");
    agregar = document.getElementById("Add");
    deleted = document.getElementById("Deleted");
    agregar.onclick = add_new;
    deleted.onclick = delete_element;
}

function drawCircle() {

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.beginPath();
    ctx.arc(XPOS, YPOS, 10, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.fillStyle = "#FF0000";
    ctx.fill();

}

function movement(e) {

    var distance = 5;
    //LEFT
    if (XPOS > 0 && e.keyCode == 37) {
        XPOS = XPOS - distance;
    }
    //UP
    if (YPOS > 0 && e.keyCode == 38) {
        YPOS = YPOS - distance;
    }
    //RIGHT
    if (XPOS < myCanvas.width && e.keyCode == 39) {
        XPOS = XPOS + distance;
    }
    //DOWN
    if (YPOS < myCanvas.height && e.keyCode == 40) {
        YPOS = YPOS + distance;
    }

    drawCircle();
}
////--------------------------------------

function add_new() {


    //document.getElementById("NewName").value = "";

    if (!document.getElementById("NewName").value) {
        window.alert("ERROR, text input field is empty. Please type a name to add.")
    }
    else {
        lista_out = document.getElementById("Lista");
        option = document.createElement("OPTION");
        option.innerHTML = document.getElementById("NewName").value;
        option.value = document.getElementById("Lista").value;
        lista_out.options.add(option);
        document.getElementById("NewName").value = "";

    }



}

function delete_element() {
    var sel_value = document.getElementById("Lista");

    if (sel_value.selectedIndex < 0) {

        window.alert("ERROR: Item not selected. Please select an element to delete.")
    }
    else {
        sel_value.remove(sel_value.selectedIndex);

    }
}


document.onload = initFunctions();
